module.exports = {
  swcMinify: true,
};
