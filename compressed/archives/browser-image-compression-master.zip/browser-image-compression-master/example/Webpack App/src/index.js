import imageCompression from 'browser-image-compression';

console.log('imageCompression', imageCompression.version);